#Gui Protoype


import sys
from PyQt5.QtCore import*
from PyQt5.QtWidgets import*

class User_interface(QWidget): #User_interface inherits from QWidget
    def __init__(self, parent=None): #parent defines parent widget
        QWidget.__init__(self, parent) #superclass constructor
        
        #set the title of the window, and position it and also set its size
        self.setWindowTitle("BattleShip Game")
        self.setGeometry(250,259,1000,500)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        #create  the  necessary layouts fot this interface 
        main_layout = QGridLayout() #the main layout is the grid layout
        left_side_layout = QVBoxLayout() #the sub left layout, to be added on the main layout
        right_side_layout =QVBoxLayout() #the sub right layout, also to be added on the main layout
        
        
        
       
        
        self.title_label = QLabel("BATTLESHIP GAME")
        self.title_label.setAlignment(Qt.AlignCenter)
                
        main_layout.addWidget(self.title_label,0, 0, 1, 2)
        
        
        
    
    #LEFTSIDE OF THE INTERFACE(WE DIVIDED EVERYTHING INTO SMALL PARTS TO MAKE THINGS EASIER AND ALSO TAKE NOTE ON HOW IT IS GOING  TO  WORK WHEN CONNECTED  TO THE TEXT CLIENT)
    
        #create the server label, and a text box to enter the server address
        #create a horinzontal layout for the the both of them
        server_layout = QHBoxLayout()
        self.server_label = QLabel("Server:")
        self.server_input = QLineEdit()
        server_layout.addWidget(self.server_label) #add the widgets to the horinzontal layout
        server_layout.addWidget(self.server_input)
        left_side_layout.addLayout(server_layout)  #add the horinzontal layout to the left side layout
        
        
        #game info section 
        #create a vertical layout for the game info
        game_info_layout = QVBoxLayout()
        
        #create the horizontal layout for the info (role, CS, GS)
        game_info_details_layout = QHBoxLayout()
        
        #create all labels separately so we can update them later
        self.role_label = QLabel("Role:")
        self.role_value = QLabel("Captain")  
        
        self.cs_label = QLabel("Captain Score:")
        self.cs_value = QLabel("0")        
        
        self.gs_label = QLabel("General Score:")
        self.gs_value = QLabel("0")         
        
        #add all labels to the horizontal layout
        game_info_details_layout.addWidget(self.role_label)
        game_info_details_layout.addWidget(self.role_value)
        game_info_details_layout.addSpacing(20)
        
        game_info_details_layout.addWidget(self.cs_label)
        game_info_details_layout.addWidget(self.cs_value)
        game_info_details_layout.addSpacing(20)
        
        game_info_details_layout.addWidget(self.gs_label)
        game_info_details_layout.addWidget(self.gs_value)
        
        # add the horizontal layout to the vertical layout
        game_info_layout.addLayout(game_info_details_layout)
        
        #now wrap the entire game_info_layout into a QGroupBox
        self.game_info_groupbox = QGroupBox("Game Info")
        self.game_info_groupbox.setLayout(game_info_layout)
        
        #add the groupbox into your left_side_layout
        left_side_layout.addWidget(self.game_info_groupbox)
        
        
        
        
        
        #game board section
        #create a vertical layout for the game board area
        game_board_layout = QVBoxLayout()
        
        #create the grid for the board
        self.board_grid = QGridLayout()
        
        #create the 6x6 labels and add them to the grid
        self.board_labels = []  #store labels in a list of lists
        
        #add column numbers at the top
        for col in range(6):
            col_label = QLabel(str(col))
            col_label.setFixedSize(40, 40)
            col_label.setAlignment(Qt.AlignCenter)
            col_label.setStyleSheet("font-weight: bold;")
            self.board_grid.addWidget(col_label, 0, col + 1) 
        
        # Add row numbers at the left
        for row in range(6):
            row_label = QLabel(str(row))
            row_label.setFixedSize(40, 40)
            row_label.setAlignment(Qt.AlignCenter)
            row_label.setStyleSheet("font-weight: bold;")
            self.board_grid.addWidget(row_label, row + 1, 0)  
        
        # Add empty labels for the actual board
        for row in range(6):
            row_labels = []
            for col in range(6):
                label = QLabel("")
                label.setFixedSize(40, 40)  
                label.setStyleSheet("border: 1px solid black; font-size: 18px;")
                label.setAlignment(Qt.AlignCenter)
                self.board_grid.addWidget(label, row + 1, col + 1)  
                row_labels.append(label)
            self.board_labels.append(row_labels)
        
        
        #create a QWidget to contain the board grid
        self.board_container = QWidget()
        self.board_container.setLayout(self.board_grid)
        self.board_container.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        
        # Add the board container into the game_board_layout
        game_board_layout.addWidget(self.board_container)
        
        
        #wrap the whole game_board_layout into a QGroupBox
        self.game_board_groupbox = QGroupBox("Game Board")
        self.game_board_groupbox.setLayout(game_board_layout)
        
        #finally, add the groupbox into your left_side_layout
        left_side_layout.addWidget(self.game_board_groupbox)
        
        
        
        
        #create widgets for move input
        self.move_label = QLabel("Move:")
        self.move_input = QLineEdit()
        self.enter_button = QPushButton("Enter")
        
       
        
        #create horizontal layout for move input area
        move_input_layout = QHBoxLayout()
        move_input_layout.addWidget(self.move_label)
        move_input_layout.addWidget(self.move_input)
        move_input_layout.addWidget(self.enter_button)
        
        # Add move_input_layout under the game board
        left_side_layout.addLayout(move_input_layout)
        
        
    #THE RIGHT SIDE OF THE INTERFACE
       
        #create a connect and disconncet buttons
        self.connect_button = QPushButton("Connect")
        self.disconnect_button = QPushButton("Disconnect")
        connection_button_layout = QHBoxLayout()
        connection_button_layout.addWidget(self.connect_button)
        connection_button_layout.addWidget(self.disconnect_button)
        right_side_layout.addLayout(connection_button_layout)
        
        
        
        
        
        #game status section 
        #create the Game Status frame
        self.game_status_group = QGroupBox("Game Status")
        self.game_status_group.setAlignment(Qt.AlignCenter) 
        game_status_layout = QVBoxLayout()
       
       #create the actual Game Status label
        self.game_status_label = QLabel("Waiting...")
        self.game_status_label.setAlignment(Qt.AlignCenter)
        self.game_status_label.setStyleSheet("font-size: 16px;") 
       
        #add the label to the internal layout
        game_status_layout.addWidget(self.game_status_label)
       
        #set the layout to the group box
        self.game_status_group.setLayout(game_status_layout)
       
        #add the game_status_group to the right side layout
        right_side_layout.addWidget(self.game_status_group)
        
        
        
        
        #create a GroupBox for Messages
        self.messages_groupbox = QGroupBox("Messages")  
        self.messages_groupbox_layout = QVBoxLayout()
        
        #create the actual text area inside it
        self.message_box = QTextEdit()
        self.message_box.setReadOnly(True)
        self.message_box.setMinimumHeight(200)
        
        #add the text area into the GroupBox layout
        self.messages_groupbox_layout.addWidget(self.message_box)
        self.messages_groupbox.setLayout(self.messages_groupbox_layout)
        
        #add the GroupBox to the right side layout
        right_side_layout.addWidget(self.messages_groupbox)
       
       
       
       
        #how to play and exit button at the  button 
        self.instructions_button = QPushButton("How To Play")
        self.exit_button =QPushButton("Exit")
        button_layout = QHBoxLayout() #create a button layout
        button_layout.addWidget(self.instructions_button) #add the  buttons to  the  horinzontal layout 
        button_layout.addWidget(self.exit_button) 
        right_side_layout.addLayout(button_layout) #add the button_layout to the right side layout 
        
        
       
       

        
        
        #styling 
        #Title label styling, increase font size, set background color to pink, add a rounded border, and create space between the heading and widgets below it 
        self.title_label.setStyleSheet("font-size: 24px;font-weight: bold;color: #4682b4; border: 2px solid #4682b4;padding: 10px;background-color: pink; border-radius: 8px;")
            
        #Game Info GroupBox Styling,make the background  color to be neutral,set font size to 14px, the color to be blue and the borders to be blue 
        self.game_info_groupbox.setStyleSheet("background-color: #f5f5f5;font-size: 14px;font-weight: bold;color: #333; border: 2px solid #4682b4; padding: 10px;")
            
        #Role label styling
        self.role_label.setStyleSheet("font-weight: bold;color: #333;")
            
        #Captain's score label styling
        self.cs_label.setStyleSheet("font-weight: bold;color: #ff6347;")
            
        #General's score label styling
        self.gs_label.setStyleSheet("font-weight: bold;color: #4682b4;")
            
        #Server label styling
        self.server_label.setStyleSheet("font-weight: bold;color: #333; font-size:16px;")
            
        #Server input field styling
        self.server_input.setStyleSheet("font-size:14px; padding:5px; border: 1px solid #ccc; border-radius:5px;")
            
        
            
        #the hover effect for all the buttons
        self.connect_button.setStyleSheet("QPushButton:hover {background-color: #90EE90;}")
        self.disconnect_button.setStyleSheet("QPushButton:hover {background-color : red;}")
        self.enter_button.setStyleSheet("QPushButton:hover {background-color: #4682b4;}")
        self.instructions_button.setStyleSheet("QPushButton:hover {background-color:#90EE90;}")
        self.exit_button.setStyleSheet("QPushButton:hover {background-color: red;}")
        
        
           
        #Game board GroupBox styling
        self.game_board_groupbox.setStyleSheet("background-color: #E3F2FD;font-size: 14px;font-weight: bold;color: #333;border: 2px solid #4682b4;padding: 10px;")
            
        
        #apply style to each label in the board_labels list
        for row in self.board_labels:
            for label in row:
                label.setStyleSheet("font-size: 18px;color: #333;font-weight: bold;text-align: center;border-radius:6px;")
                
        #style the move input 
        self.move_label.setStyleSheet("font-weight: bold; color: #333; font-size: 16px;")
        self.move_input.setStyleSheet("font-size: 14px; padding: 5px; border: 1px solid #ccc; border-radius: 5px;")   
        
        
        #style the game status group box
        self.game_status_group.setStyleSheet("border: 2px solid #4682b4;font-size:14px;padding: 10px;color:#333;font-weight:bold;")
        
        #style the game status label
        self.game_status_label.setStyleSheet("font-size: 18px;color: #333;font-weight: bold;")
        
        
        
        #style the Messages group box
        self.messages_groupbox.setStyleSheet("background-color: #F5F5F5;font-size:14px;border: 2px solid #4682b4;padding: 10px;color:#333; font-weight:bold;")
        
        #style the QTextEdit inside the Messages group box
        self.message_box.setStyleSheet("background-color: #E3F2FD;font-size: 14px;color: #333;padding: 10px;border: 1px solid #ccc;border-radius: 5px;")
        
        
    
        
        #add left and right layouts into the main grid
        main_layout.addLayout(left_side_layout, 1, 0) 
        main_layout.addLayout(right_side_layout, 1, 1) 
        
        
        #set the main layout to the window
        self.setLayout(main_layout)  
         
         
        #to help the user know what to do 
        self.connect_button.setToolTip("Click to connect to the server")
        self.disconnect_button.setToolTip("Click to disconnect from the server")
        self.exit_button.setToolTip("Click to exit the game")
        self.instructions_button.setToolTip("Click to read instructions on how to play the game")     
        
        
        #event handling, connecting signals and slots
        self.connect_button.clicked.connect(self.connect_button_clicked)
        self.disconnect_button.clicked.connect(self.disconnect_button_clicked)
        self.enter_button.clicked.connect(self.enter_button_clicked)
        self.instructions_button.clicked.connect(self.instructions_button_clicked)
        self.exit_button.clicked.connect(self.exit_button_clicked)
        
    #temporarily methods    
    def connect_button_clicked(self):
        self.message_box.append("Connect button clicked.")
        
    def disconnect_button_clicked(self):
        self.message_box.append("Disconnect button clicked.")
        
    def enter_button_clicked(self):
        self.message_box.append("Enter button clicked.")
        
    def instructions_button_clicked(self):
        self.message_box.append("How to play button clicked.")
        instructions = (
            "HOW TO PLAY BATTLESHIP\n\n"
            "1. Enter the server address at the top.\n"
            "2. Click the 'Connect' button to connect to the server.\n"
            "3. Check your role: Captain or General.\n"
            "4. Wait for the Game Status to say it's your turn.\n"
             "5. When it's your turn:\n"
            "   - Enter your move as 'row,column' (example: 2,4).\n"
            "   - Click 'Enter Move' to submit.\n"
            "6. Game board updates after each move (hit-Capital letter of the first role letter/miss-small letter of the first role letter).\n"
            "7. Wait during your opponent's turn.\n"
            "8. Game ends when all ships are hit.\n"
            "9. Choose to play again or exit.\n"
            "10. Use 'Instructions' for help anytime.\n"
            "11. 'Disconnect' to leave early.\n\n"
            "NOTE: Rows and columns go from 0 to 5.\n"
            "Example Moves: 0,5 or 5,0."
        )
        QMessageBox.information(self, "Instructions", instructions)        
    def exit_button_clicked(self):
        self.message_box.append("Exit button has been clicked")
        
        
        
        
def main():
    app = QApplication(sys.argv)
    my_window = User_interface()
    my_window.show()
    sys.exit(app.exec_())
main()

