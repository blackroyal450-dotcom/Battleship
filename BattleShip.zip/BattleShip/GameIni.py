###########################
# DO NOT MODIFY THIS FILE #
###########################

PORT = 12345
BUFFER_SIZE = 32
BUFFER_STR = '{0:^'+ str(BUFFER_SIZE) +'}'

GAME_NAME = 'BattleShip'
BOARD_SIZE = (6,6)