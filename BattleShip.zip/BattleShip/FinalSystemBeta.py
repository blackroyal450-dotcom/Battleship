from GameClient import GameClient
import threading
import sys
from PyQt5.QtCore import*
from PyQt5.QtWidgets import*
from PyQt5.QtMultimedia import*




#create  a thread class to  read incoming  server messages 
class ReceiveThread(QThread):
    message_received = pyqtSignal(str)
    connection_lost  = pyqtSignal()

    def __init__(self, sock):
        super().__init__()
        self.sock = sock
        self.running = True

    def run(self):
        while self.running:
            try:
                raw = self.sock.recv(4096)
                if not raw:
                    self.connection_lost.emit()
                    break
                msg = raw.decode().strip()
                self.message_received.emit(msg)
            except ConnectionResetError:
                self.connection_lost.emit()
                break
            except Exception:
                continue

    def stop(self):
        self.running = False
        self.wait()



class User_interface(QWidget, GameClient): #User_interface inherits from QWidget
    def __init__(self, parent=None): #parent defines parent widget
        QWidget.__init__(self, parent) #superclass constructor
        GameClient.__init__(self)
               
        
        self.role = None 
        self.letter_colors= {}
        #set the title of the window, and position it and also set its size
        self.setWindowTitle("BattleShip Game")
        self.setGeometry(250,259,1000,500)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        #create  the  necessary layouts fot this interface 
        main_layout = QGridLayout() #the main layout is the grid layout
        left_side_layout = QVBoxLayout() #the sub left layout, to be added on the main layout
        right_side_layout =QVBoxLayout() #the sub right layout, also to be added on the main layout
        
        #create sound variables for the nerd zone part(exhausting)
        self.miss_sound = QSoundEffect()
        self.miss_sound.setSource(QUrl.fromLocalFile("Sounds/miss.wav"))
        self.miss_sound.setVolume(0.2)         
        
        self.hit_sound = QSoundEffect()
        self.hit_sound.setSource(QUrl.fromLocalFile("Sounds/hit.wav"))
        self.hit_sound.setVolume(0.2)
        
        self.win_sound = QSoundEffect()
        self.win_sound.setSource(QUrl.fromLocalFile("Sounds/win.wav"))
        self.win_sound.setVolume(0.2)
        
        
        self.lose_sound = QSoundEffect()
        self.lose_sound.setSource(QUrl.fromLocalFile("Sounds/lose.wav"))
        self.lose_sound.setVolume(0.2)        
        
        self.tie_sound = QSoundEffect()
        self.tie_sound.setSource(QUrl.fromLocalFile("Sounds/tie.wav"))
        self.tie_sound.setVolume(0.2)                
        
        self.is_my_turn = False
        self.setStyleSheet("background-color: lightblue;")
        
       
        
        self.title_label = QLabel("BATTLESHIP GAME")
        self.title_label.setAlignment(Qt.AlignCenter)
                
        main_layout.addWidget(self.title_label,0, 0, 1, 2)
        


        
        #LEFTSIDE OF THE INTERFACE(WE DIVIDED EVERYTHING INTO SMALL PARTS TO MAKE THINGS EASIER AND ALSO TAKE NOTE ON HOW IT IS GOING  TO  WORK WHEN CONNECTED  TO THE TEXT CLIENT)
        #create the server label, and a text box to enter the server address
        #create a horinzontal layout for the the both of them
        server_layout = QHBoxLayout()
        self.server_label = QLabel("Server:")
        self.server_input = QLineEdit()
        server_layout.addWidget(self.server_label) #add the widgets to the horinzontal layout
        server_layout.addWidget(self.server_input)
        left_side_layout.addLayout(server_layout)  #add the horinzontal layout to the left side layout        
        #game info section 
        #create a vertical layout for the game info
        game_info_layout = QVBoxLayout()
        
        #create the horizontal layout for the info (role, CS, GS)
        game_info_details_layout = QHBoxLayout()
        
        #create all labels separately so we can update them later
        self.role_label = QLabel("Role:")
        self.role_value = QLabel("None")  
        
        self.cs_label = QLabel("Captain Score:")
        self.cs_value = QLabel("0")        
        
        self.gs_label = QLabel("General Score:")
        self.gs_value = QLabel("0")         
        
        #add all labels to the horizontal layout
        game_info_details_layout.addWidget(self.role_label)
        game_info_details_layout.addWidget(self.role_value)
        game_info_details_layout.addSpacing(20)
        
        game_info_details_layout.addWidget(self.cs_label)
        game_info_details_layout.addWidget(self.cs_value)
        game_info_details_layout.addSpacing(20)
        
        game_info_details_layout.addWidget(self.gs_label)
        game_info_details_layout.addWidget(self.gs_value)
        
        # add the horizontal layout to the vertical layout
        game_info_layout.addLayout(game_info_details_layout)
        
        #now wrap the entire game_info_layout into a QGroupBox
        self.game_info_groupbox = QGroupBox("Game Info")
        self.game_info_groupbox.setLayout(game_info_layout)
        
        #add the groupbox into your left_side_layout
        left_side_layout.addWidget(self.game_info_groupbox)
        
        
        
        
        
        #game board section
        #create a vertical layout for the game board area
        game_board_layout = QVBoxLayout()
        
        #create the grid for the board
        self.board_grid = QGridLayout()
        
        #create the 6x6 labels and add them to the grid
        self.board_labels = []  #store labels in a list of lists
        
        #add column numbers at the top
        for col in range(6):
            col_label = QLabel(str(col))
            col_label.setFixedSize(60, 60)
            col_label.setAlignment(Qt.AlignCenter)
            col_label.setStyleSheet("font-weight: bold;font-size:24px;")
            self.board_grid.addWidget(col_label, 0, col + 1) 
        
        # Add row numbers at the left
        for row in range(6):
            row_label = QLabel(str(row))
            row_label.setFixedSize(60, 60)
            row_label.setAlignment(Qt.AlignCenter)
            row_label.setStyleSheet("font-weight: bold;font-size: 24px;")
            self.board_grid.addWidget(row_label, row + 1, 0)  
        
        # Add empty labels for the actual board
        for row in range(6):
            row_labels = []
            for col in range(6):
                label = QLabel("")
                label.setFixedSize(60, 60)  
                label.setStyleSheet("border: 1px solid black; font-size: 24px;")
                label.setAlignment(Qt.AlignCenter)
                self.board_grid.addWidget(label, row + 1, col + 1)  
                row_labels.append(label)
            self.board_labels.append(row_labels)
        
        
        #create a QWidget to contain the board grid
        self.board_container = QWidget()
        self.board_container.setLayout(self.board_grid)
        self.board_container.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        
        # Add the board container into the game_board_layout
        game_board_layout.addWidget(self.board_container)
        
        
        #wrap the whole game_board_layout into a QGroupBox
        self.game_board_groupbox = QGroupBox("Game Board")
        self.game_board_groupbox.setLayout(game_board_layout)
        
        #finally, add the groupbox into your left_side_layout
        left_side_layout.addWidget(self.game_board_groupbox)
        
        
        
        
        #create widgets for move input
        self.move_label = QLabel("Move:")
        self.move_input = QLineEdit()
        self.move_input.setEnabled(False)
        self.enter_button = QPushButton("Enter")
        self.enter_button.setEnabled(False)
        
       
        
        #create horizontal layout for move input area
        move_input_layout = QHBoxLayout()
        move_input_layout.addWidget(self.move_label)
        move_input_layout.addWidget(self.move_input)
        move_input_layout.addWidget(self.enter_button)
        
        # Add move_input_layout under the game board
        left_side_layout.addLayout(move_input_layout)
        
        
        #RIGHT SIDE OF THE INTERFACE 
        #create a connect and disconncet buttons
        self.connect_button = QPushButton("Connect")
        self.color_combo = QComboBox()
        self.color_combo.addItems(["Default","Light Pink", "Sky Blue", "Cool Blue", "Light Gray"])        
        connection_button_layout = QHBoxLayout()
        connection_button_layout.addWidget(self.connect_button)
        connection_button_layout.addWidget(self.color_combo)
        right_side_layout.addLayout(connection_button_layout)
        
        
        
        
        
        #game status section 
        #create the Game Status frame
        self.game_status_group = QGroupBox("Game Status")
        self.game_status_group.setAlignment(Qt.AlignCenter) 
        game_status_layout = QVBoxLayout()
       
       #create the actual Game Status label
        self.game_status_label = QLabel("Waiting for connection...")
        self.game_status_label.setAlignment(Qt.AlignCenter)
        self.game_status_label.setStyleSheet("font-size: 16px;") 
       
        #add the label to the internal layout
        game_status_layout.addWidget(self.game_status_label)
       
        #set the layout to the group box
        self.game_status_group.setLayout(game_status_layout)
       
        #add the game_status_group to the right side layout
        right_side_layout.addWidget(self.game_status_group)
        
        
        
        
        #create a GroupBox for Messages
        self.messages_groupbox = QGroupBox("Messages")  
        self.messages_groupbox_layout = QVBoxLayout()
        
        #create the actual text area inside it
        self.message_box = QTextEdit()
        self.message_box.setReadOnly(True)
        self.message_box.setMinimumHeight(200)
        
        #add the text area into the GroupBox layout
        self.messages_groupbox_layout.addWidget(self.message_box)
        self.messages_groupbox.setLayout(self.messages_groupbox_layout)
        
        #add the GroupBox to the right side layout
        right_side_layout.addWidget(self.messages_groupbox)
       
       
       
       
        #how to play and exit button at the  button 
        self.instructions_button = QPushButton("How To Play")
        self.exit_button =QPushButton("Exit")
        self.play_again_button = QPushButton("Play Again")
        button_layout = QHBoxLayout() #create a button layout
        button_layout.addWidget(self.instructions_button) #add the  buttons to  the  horinzontal layout 
        button_layout.addWidget(self.play_again_button)
        button_layout.addWidget(self.exit_button) 
        right_side_layout.addLayout(button_layout) #add the button_layout to the right side layout         
        self.play_again_button.setVisible(False)
        self.exit_button.setVisible(False)        
        
        
        #STYLING
        #Title label styling, increase font size, set background color to pink, add a rounded border, and create space between the heading and widgets below it 
        self.title_label.setStyleSheet("font-size: 24px;font-weight: bold;color: #4682b4; border: 2px solid #4682b4;padding: 10px;background-color: pink; border-radius: 8px;")
        #Game Info GroupBox Styling,make the background  color to be neutral,set font size to 14px, the color to be blue and the borders to be blue 
        self.game_info_groupbox.setStyleSheet("background-color: lightblue;font-size: 14px;font-weight: bold;color: #333; border: 2px solid black; padding: 10px;") 
        #Role label styling
        self.role_label.setStyleSheet("font-weight: bold;color: #333;")   
        #Captain's score label styling
        self.cs_label.setStyleSheet("font-weight: bold;color: red;")
        #General's score label styling
        self.gs_label.setStyleSheet("font-weight: bold;color: blue;") 
        #Server label styling
        self.server_label.setStyleSheet("font-weight: bold;color: #333; font-size:16px;") 
        #Server input field styling
        self.server_input.setStyleSheet("font-size:14px; padding:5px; border: 2px solid black; border-radius:5px;background-color:white;") 
        #the hover effect for all the buttons
        self.connect_button.setStyleSheet("QPushButton:hover {background-color: #90EE90;}")
        self.enter_button.setStyleSheet("QPushButton:hover {background-color: #4682b4;}")
        self.instructions_button.setStyleSheet("QPushButton:hover {background-color:#90EE90;}")
        self.exit_button.setStyleSheet("QPushButton:hover {background-color: red;}")
        self.play_again_button.setStyleSheet("QPushButton:hover {background-color: green;}")
        #Game board GroupBox styling
        self.game_board_groupbox.setStyleSheet("background-color: lightblue;font-size: 14px;font-weight: bold;color: #333;border: 2px solid black;padding: 10px;border-radius:1px;")
        #apply style to each label in the board_labels list
        for row in self.board_labels:
            for label in row:
                label.setStyleSheet("font-size: 18px;color: #333;font-weight: bold;text-align: center;border-radius:6px;")
                
        #style the move input 
        self.move_label.setStyleSheet("font-weight: bold; color: #333; font-size: 16px;")
        self.move_input.setStyleSheet("font-size: 14px; padding: 5px; border: 2px solid black; border-radius: 5px;background-color:white;")   
        #style the game status group box
        self.game_status_group.setStyleSheet("border: 2px solid black;font-size:14px;padding: 10px;background-color:#E3F2FD;font-weight:bold;")
        #style the game status label
        self.game_status_label.setStyleSheet("font-size: 18px;color: green;font-weight: bold;")
        #style the Messages group box
        self.messages_groupbox.setStyleSheet("background-color: #F5F5F5;font-size:14px;border: 2px solid black;padding: 10px;color:#333; font-weight:bold;border-radius:2px;")
        #style the QTextEdit inside the Messages group box
        self.message_box.setStyleSheet("background-color: #E3F2FD;font-size: 14px;color: #333;padding: 10px;border: 1px solid #ccc;border-radius: 5px;")
        
        #PUT  EVERYTHING TOGETHER 
        #add left and right layouts into the main grid
        main_layout.addLayout(left_side_layout, 1, 0) 
        main_layout.addLayout(right_side_layout, 1, 1) 
        #set the main layout to the window
        self.setLayout(main_layout)          
        
        
        #to help the user know what to do
        self.connect_button.setToolTip("Click to connect to the server")
        self.exit_button.setToolTip("Click to exit the game")
        self.instructions_button.setToolTip("Click to read instructions on how to play the game")             
        
        
        #event handling, connecting signals and slots
        self.connect_button.clicked.connect(self.connect_server)
        self.enter_button.clicked.connect(self.submit_move)
        self.color_combo.currentTextChanged.connect(self.change_background_color)
        self.instructions_button.clicked.connect(self.get_instructions)
        self.exit_button.clicked.connect(self.exit_game)        
        self.play_again_button.clicked.connect(self.on_yes_clicked)
        
    #a method executed when the connect button is clicked         
    def connect_server(self):
        #get the server address from the edit box 
        server_address = self.server_input.text().strip()
        if not server_address:
            #if the user presses connect without entering anything, prompt them to enter a server address
            self.message_box.append("Please enter a server address.")
            return
    
        
        self.message_box.append("Getting connection...")
        self.game_status_label.setText("Getting connection...")
    
        #after 2 second, show connecting...
        QTimer.singleShot(2000, lambda: self.message_box.append("Connecting..."))
        QTimer.singleShot(2000, lambda: self.game_status_label.setText("Connecting..."))
    
        #after 3 seconds, attempt connection
        def try_connection():
            try:    
                self.connect_to_server(server_address)
                self.message_box.append("Connected to server.")
                self.game_status_label.setText("Connected")
                self.recv_thread = ReceiveThread(self.socket)   # use GameClient.socket
                self.recv_thread.message_received.connect(self.handle_message)
                self.recv_thread.connection_lost.connect(self.on_connection_lost)
                self.recv_thread.start()                

            except Exception as e:
                self.message_box.append(f"Connection failed: {e}")
                self.game_status_label.setText("Connection failed")
    
        QTimer.singleShot(3000, try_connection)        
        
        
    def on_connection_lost(self):
        self.message_box.append("⚠️Connection to server lost.")
        self.game_status_label.setText("Disconnected")
        self.move_input.setEnabled(False)
        
        
    #a method to be executed when the player clicks the enter button   
    def submit_move(self):
        move = self.move_input.text().strip()  #Get the move
        #Send the move to the server
        self.send_message(move)
        #disable the input after the move is submitted
        self.move_input.setEnabled(False)
        self.is_my_turn = False  #set the flag to false since the player has made their move    
        
        
    #A method executed when the "How to play" button is clicked  
    def get_instructions(self):
        instructions = (
            "HOW TO PLAY BATTLESHIP\n\n"
            "1. Enter the server address at the top.\n"
            "2. Click the 'Connect' button to connect to the server.\n"
            "3. Check your role: Captain or General.\n"
            "4. Wait for the Game Status to say it's your turn.\n"
             "5. When it's your turn:\n"
            "   - Enter your move as 'row,column' (example: 2,4).\n"
            "   - Click 'Enter Move' to submit.\n"
            "6. Game board updates after each move (hit-Capital letter of the first role letter/miss-small letter of the first role letter).\n"
            "7. Wait during your opponent's turn.\n"
            "8. Game ends when all ships are hit.\n"
            "9. Choose to play again or exit.\n"
            "10. Use 'Instructions' for help anytime.\n"
            "NOTE: Rows and columns go from 0 to 5.\n"
            "Example Moves: 0,5 or 5,0."
        )
        QMessageBox.information(self, "Instructions", instructions)     
        
        
    #a method executed when the player clicks exit   
    def exit_game(self):
        self.send_message("n")
        self.stop_pulsing_buttons()
        self.message_box.append("Thanks for playing")
        self.game_status_label.setText("Disconnected, you exited the game!")
        #close the window
        self.play_again_button.setVisible(False)
        self.exit_button.setVisible(False)             
    
    
    
    #nerd zone
    def change_background_color(self, color_name):
        if color_name == "Default":
            self.game_info_groupbox.setStyleSheet("background-color: lightblue;font-size: 14px;font-weight: bold;color: #333; border: 2px solid black; padding: 10px;")
            self.setStyleSheet("background-color: lightblue; color:black;")
            self.game_board_groupbox.setStyleSheet("background-color: lightblue; font-size: 14px; font-weight: bold; color: #333; border: 2px solid black; padding: 10px; border-radius:1px;")
            for row in self.board_labels:
                for label in row:
                    label.setStyleSheet("font-size: 18px; color: #333; font-weight: bold; text-align: center; border-radius:6px;")
                    
        elif color_name == "Light Pink":
            self.game_info_groupbox.setStyleSheet("background-color: #f7cac9;font-size: 14px;font-weight: bold;color: #333; border: 2px solid black; padding: 10px;")
            self.setStyleSheet("background-color: #f7cac9; color: black;")
            self.game_board_groupbox.setStyleSheet("background-color: #f7cac9; font-size: 14px; font-weight: bold; color: #333; border: 2px solid black; padding: 10px; border-radius:1px;")
            for row in self.board_labels:
                for label in row:
                    label.setStyleSheet("font-size: 18px; color: #333; font-weight: bold; text-align: center; border-radius:6px;")
        
        elif color_name == "Sky Blue":
            self.game_info_groupbox.setStyleSheet("background-color: #87cefa;font-size: 14px;font-weight: bold;color: #333; border: 2px solid black; padding: 10px;")
            self.setStyleSheet("background-color: #87cefa; color: black;")
            self.game_board_groupbox.setStyleSheet("background-color: #87cefa; font-size: 14px; font-weight: bold; color: #333; border: 2px solid black; padding: 10px; border-radius:1px;")
            for row in self.board_labels:
                for label in row:
                    label.setStyleSheet("font-size: 18px; color: #333; font-weight: bold; text-align: center; border-radius:6px;")
        
        elif color_name == "Cool Blue":
            self.game_info_groupbox.setStyleSheet("background-color: #cbe8f6;font-size: 14px;font-weight: bold;color: #333; border: 2px solid black; padding: 10px;")
            self.setStyleSheet("background-color: #cbe8f6; color: black;")
            self.game_board_groupbox.setStyleSheet("background-color: #cbe8f6; font-size: 14px; font-weight: bold; color: #333; border: 2px solid black; padding: 10px; border-radius:1px;")
            for row in self.board_labels:
                for label in row:
                    label.setStyleSheet("font-size: 18px; color: #333; font-weight: bold; text-align: center; border-radius:6px;")
        
        elif color_name == "Light Gray":
            self.game_info_groupbox.setStyleSheet("background-color: #f0f0f0;font-size: 14px;font-weight: bold;color: #333; border: 2px solid black; padding: 10px;")
            self.setStyleSheet("background-color: #f0f0f0; color: black;")
            self.game_board_groupbox.setStyleSheet("background-color: #f0f0f0; font-size: 14px; font-weight: bold; color: #333; border: 2px solid black; padding: 10px; border-radius:1px;")
            for row in self.board_labels:
                for label in row:
                    label.setStyleSheet("font-size: 18px; color: #333; font-weight: bold; text-align: center; border-radius:6px;") 
                    
        for (row, col), color in self.letter_colors.items():
            self.board_labels[row][col].setStyleSheet(f"font-weight: bold; color: {color}; border-radius:6px; font-size: 23px;")  
                            
    #a method  to erase the game board 
    def clear_board(self):
        for row in range(6):
            for col in range(6):
                label = self.board_labels[row][col]
                label.setText("")    
                
                
                
    #updating the scores on the GUI
    def update_score_labels(self):
        self.cs_value.setText(str(self.captain_score))
        self.gs_value.setText(str(self.general_score))    
        
    #asking the user if they wanna play again button
    def on_yes_clicked(self):
        self.send_message("y")
        self.stop_pulsing_buttons()
        self.message_box.append("Starting a new game...")
        self.game_status_label.setText("Waiting for the next game...")
        self.play_again_button.setVisible(False)
        self.exit_button.setVisible(False)        
    
    
    def pulse_button(self, button):
        #Store animations to stop them later
        if not hasattr(self, 'button_pulse_animations'):
            self.button_pulse_animations = []
    
        #Get the button's original geometry
        start_rect = button.geometry()
        shrink_width = int(start_rect.width() * 0.9)
        shrink_height = int(start_rect.height() * 0.9)
    
        #create pulsing animation
        pulse = QPropertyAnimation(button, b"geometry")
        pulse.setDuration(500)
        pulse.setLoopCount(-1)  
        pulse.setEasingCurve(QEasingCurve.InOutQuad)
    
        #nnimate between normal and slightly smaller
        pulse.setStartValue(start_rect)
        pulse.setKeyValueAt(0.5, QRect(
            start_rect.x() + (start_rect.width() - shrink_width) // 2,
            start_rect.y() + (start_rect.height() - shrink_height) // 2,
            shrink_width,
            shrink_height
        ))
        pulse.setEndValue(start_rect)
    
        pulse.start()
        self.button_pulse_animations.append((button, pulse))    
    
    def stop_pulsing_buttons(self):
        if hasattr(self, 'button_pulse_animations'):
            for button, animation in self.button_pulse_animations:
                animation.stop()
            self.button_pulse_animations.clear()
    
        
    #handling messages from the server  
    @pyqtSlot(str)
    def handle_message(self, msg):
        if msg.startswith("new game"):
            
            
            #extract role 
            info = msg.split(",")
            #referencing the role from list info
            self.role = info[1]
            
            #get the role name
            if self.role == "C":
                role_name = "Captain"
            else:
                role_name = "General"
            
            #display role and update gui
            self.message_box.append(f"New game started! you are the {role_name}.")
            self.role_value.setText(role_name)#set the role name on the gui 
            self.game_status_label.setText("Connected")
            self.move_input.setEnabled(True)
            self.enter_button.setEnabled(True)    
            #Clear the board
            self.clear_board()
            
            #Reset scores
            self.captain_score = 0
            self.general_score = 0
            
            #Update score display
            self.update_score_labels()
            
            
        elif msg.startswith("your move"):
            # Update the game GUI when it's the player's turn
            self.message_box.append("your move.")
            self.game_status_label.setText("Your turn...")
            self.move_input.clear()  #clear the input field 
            self.move_input.setEnabled(True)  #enable the move input field
            self.enter_button.setEnabled(True)
            self.is_my_turn = True  #set the flag that it's now the player's turn
            
        elif msg == "opponents move":
            #Handle the opponent's move
            self.message_box.append("Opponent's move")
            self.game_status_label.setText("Waiting for opponent's move...")
            self.move_input.setEnabled(False)  #Disable input while waiting for the opponent
            self.enter_button.setEnabled(False)
        
        elif msg.startswith("valid move"):
            #get the player who made the valid move, their position, and the scores for both players
            info = msg.split(",")
            move_role = info[1]
            row = int(info[2])
            col = int(info[3])
            new_captain_score = int(info[4])
            new_general_score = int(info[5])        
    
    
            if move_role == "C":
                previous_score = self.captain_score
                current_score = new_captain_score
        
            else:
                previous_score = self.general_score
                current_score = new_general_score      
    
            #decide if it was a hit (uppercase) or miss (lowercase)
            if current_score > previous_score:
                mark = move_role.upper()  #Hit
                self.hit_sound.play()
            else:
                mark = move_role.lower()  #Miss  
                self.miss_sound.play()
            
            #update the gui
            self.board_labels[row][col].setText(mark)
            
            
            # Set color and style based on the role, regardless of hit or miss
            if move_role == "C":  #Captain (C)
                color = "red"  #Red for Captain
            else:  #General (G)
                color = "blue"  #Blue for General
            letter = self.board_labels[row][col].text()
            self.letter_colors[(row, col)] = color
            #Apply the same color regardless of hit (uppercase) or miss (lowercase)
            self.board_labels[row][col].setStyleSheet(f"font-weight: bold; color: {color};border-radius:6px;font-size:23px;")           
           
    
            #update internal scores
            self.captain_score = new_captain_score
            self.general_score = new_general_score  
            
            
            #update score labels
            self.cs_value.setText(str(self.captain_score))
            self.gs_value.setText(str(self.general_score)) 
            
            #show messages in the message box
            if move_role == self.role:
                if mark.isupper():
                    self.message_box.append(f"Nice shot! You hit a ship at ({row}, {col})!")
                    
                else:
                    self.message_box.append(f"Oops! You missed at ({row}, {col}) nothing but water!!")
                    
            else:  # If it's the opponent's move
                if mark.isupper():
                    self.message_box.append(f"Opponent hit a ship at ({row}, {col}) Uh-ohh!")
                    
                else:
                    self.message_box.append(f"Opponent missed at ({row}, {col}).")
                                 
                        
                
        elif msg == "invalid move":
            self.message_box.append("Invalid move, try Again!")
        
        elif msg.startswith("game over"):
            info = msg.split(",") # Split the message from the server into a list
            winner = info[1].strip()  # Get the letter of the winner
        
            #Update the message box with the final results
            self.message_box.append("\nGame Over")
            self.message_box.append(f"Final Scores:")
            self.message_box.append(f"Captain: {self.captain_score}")
            self.message_box.append(f"General: {self.general_score}")
        
            #Display game result (tie, win, or lose)
            if winner == "T":
                self.message_box.append("It's a Tie!")
                self.game_status_label.setText("Game Over! It's a Tie!")
                self.tie_sound.play()
            elif winner == self.role:
                self.message_box.append("You won!")
                self.game_status_label.setText("Game Over! You won!")
                self.win_sound.play()
            else:
                self.message_box.append("You lost, better luck next time!")
                self.game_status_label.setText("Game Over! You lost.")
                self.lose_sound.play()
            
            self.enter_button.setDisabled(True)#Disable move button    
            
           
        
        elif msg.startswith("play again"):
                #QTimer.singleShot(0, self.show_play_again_dialog)
            self.play_again_button.setVisible(True)
            self.exit_button.setVisible(True)  
            self.pulse_button(self.play_again_button)
            self.pulse_button(self.exit_button)            
            self.message_box.append("Do you want to play again?")
            self.game_status_label.setText("play again? Click on the buttons below")
         
        elif msg.startswith("exit"):
            self.message_box.append("The game has ended. One of the players exited the game.")
            self.game_status_label.setText("Game ended, player left")
            self.recv_thread.stop()
            self.socket.close()
         
def main():
    app = QApplication(sys.argv)
    my_window = User_interface()
    my_window.show()
    sys.exit(app.exec_())
main()    