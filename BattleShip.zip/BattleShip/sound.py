from GameClient import GameClient
import threading
import sys
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
import os

class ReceiveThread(QThread):
    message_received = pyqtSignal(str)
    connection_lost = pyqtSignal()

    def __init__(self, sock):
        super().__init__()
        self.sock = sock
        self.running = True

    def run(self):
        while self.running:
            try:
                raw = self.sock.recv(4096)
                if not raw:
                    self.connection_lost.emit()
                    break
                msg = raw.decode().strip()
                self.message_received.emit(msg)
            except ConnectionResetError:
                self.connection_lost.emit()
                break
            except Exception:
                continue

    def stop(self):
        self.running = False
        self.wait()

class User_interface(QWidget, GameClient):
    def __init__(self, parent=None):
        QWidget.__init__(self, parent)
        GameClient.__init__(self)

        self.setWindowTitle("BattleShip Game")
        self.setGeometry(250, 259, 1000, 500)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setStyleSheet("background-color: lightblue;")

        main_layout = QGridLayout()
        left_side_layout = QVBoxLayout()
        right_side_layout = QVBoxLayout()

        self.connect_button = QPushButton("Connect")
        self.chat_button = QPushButton("Chat")
        self.enter_button = QPushButton("Enter")

        self.play_again_button = QPushButton("Play Again")
        self.play_again_button.setStyleSheet("QPushButton { background-color: #90ee90; font-weight: bold; padding: 8px; border-radius: 6px; } QPushButton:hover { background-color: #2e8b57; color: white; }")
        self.play_again_button.hide()
        self.play_again_button.clicked.connect(self.handle_play_again_clicked)
        right_side_layout.addWidget(self.play_again_button)

        self.messages_groupbox = QGroupBox("Messages")
        self.messages_groupbox_layout = QVBoxLayout()
        self.message_box = QTextEdit()
        self.message_box.setReadOnly(True)
        self.message_box.setMinimumHeight(200)
        self.messages_groupbox_layout.addWidget(self.message_box)
        self.messages_groupbox.setLayout(self.messages_groupbox_layout)
        right_side_layout.addWidget(self.messages_groupbox)

        self.instructions_button = QPushButton("How To Play")
        self.exit_button = QPushButton("Exit")
        button_layout = QHBoxLayout()
        button_layout.addWidget(self.instructions_button)
        button_layout.addWidget(self.exit_button)
        right_side_layout.addLayout(button_layout)

        main_layout.addLayout(left_side_layout, 1, 0)
        main_layout.addLayout(right_side_layout, 1, 1)
        self.setLayout(main_layout)

        self.connect_button.clicked.connect(self.connect_button_clicked)
        self.chat_button.clicked.connect(self.open_chat)
        self.enter_button.clicked.connect(self.submit_move)
        self.instructions_button.clicked.connect(self.instructions_button_clicked)
        self.exit_button.clicked.connect(self.exit_button_clicked)

    def connect_button_clicked(self):
        self.message_box.append("[DEBUG] Connect button clicked - implement logic here.")

    def open_chat(self):
        self.message_box.append("[DEBUG] Chat button clicked - implement chat here.")

    def submit_move(self):
        self.message_box.append("[DEBUG] Submit move - implement move submission.")

    def instructions_button_clicked(self):
        instructions = (
            "HOW TO PLAY BATTLESHIP\n\n"
            "1. Enter the server address at the top.\n"
            "2. Click the 'Connect' button to connect to the server.\n"
            "3. Check your role: Captain or General.\n"
            "4. Wait for the Game Status to say it's your turn.\n"
            "5. When it's your turn:\n"
            "   - Enter your move as 'row,column' (example: 2,4).\n"
            "   - Click 'Enter Move' to submit.\n"
            "6. Game board updates after each move (hit - uppercase letter / miss - lowercase).\n"
            "7. Wait during your opponent's turn.\n"
            "8. Game ends when all ships are hit.\n"
            "9. Choose to play again or exit.\n"
            "10. Use 'Instructions' for help anytime.\n"
            "NOTE: Rows and columns go from 0 to 5.\n"
            "Example Moves: 0,5 or 5,0."
        )
        QMessageBox.information(self, "Instructions", instructions)

    def exit_button_clicked(self):
        self.message_box.append("Exit button has been clicked")
        self.close()

    def clear_board(self):
        for row in range(6):
            for col in range(6):
                label = self.board_labels[row][col]
                label.setText("")

    def update_score_labels(self):
        self.cs_value.setText(str(self.captain_score))
        self.gs_value.setText(str(self.general_score))

    def handle_play_again_clicked(self):
        self.send_message("y")
        self.message_box.append("You chose to play again. Waiting for new game...")
        self.play_again_button.hide()
        self.move_input.setEnabled(False)
        self.enter_button.setEnabled(False)
        self.clear_board()

    @pyqtSlot(str)
    def handle_message(self, msg):
        if msg.startswith("game over"):
            info = msg.split(",")
            winner = info[1]

            self.message_box.append("\nGame Over")
            self.message_box.append("Final Scores:")
            self.message_box.append(f"Captain: {self.captain_score}")
            self.message_box.append(f"General: {self.general_score}")

            if winner == "T":
                self.message_box.append("It's a Tie!")
                self.game_status_label.setText("Game Over! It's a Tie!")
            elif winner == self.role:
                self.message_box.append("You won!")
                self.game_status_label.setText("Game Over! You won!")
            else:
                self.message_box.append("You lost, better luck next time!")
                self.game_status_label.setText("Game Over! You lost.")

            self.enter_button.setDisabled(True)
            self.play_again_button.show()

        elif msg.startswith("play again"):
            self.play_again_button.show()

        elif msg.startswith("exit"):
            self.message_box.append("The game has ended. One of the players exited the game.")
            self.game_status_label.setText("Game ended, player left")


def main():
    app = QApplication(sys.argv)
    my_window = User_interface()
    my_window.show()
    sys.exit(app.exec_())

main()



    #def run(self):
        #while self.running:
            #try:
                #raw = self.sock.recv(4096)
                #if not raw:
                    #self.connection_lost.emit()
                    #break
                #msg = raw.decode().strip()
                #self.message_received.emit(msg)
            #except ConnectionResetError:
                #self.connection_lost.emit()
                #break
            #except Exception:
                #continue

    #def stop(self):
        #self.running = False
        #self.wait()


#class User_interface(QWidget, GameClient):
    #def __init__(self, parent=None):
        #QWidget.__init__(self, parent)
        #GameClient.__init__(self)

        #self.setWindowTitle("BattleShip Game")
        #self.setGeometry(250, 259, 1000, 500)
        #self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        #main_layout = QGridLayout()
        #left_side_layout = QVBoxLayout()
        #right_side_layout = QVBoxLayout()
        #self.is_my_turn = False
        #self.setStyleSheet("background-color: lightblue;")

        #self.title_label = QLabel("BATTLESHIP GAME")
        #self.title_label.setAlignment(Qt.AlignCenter)
        #main_layout.addWidget(self.title_label, 0, 0, 1, 2)

        #server_layout = QHBoxLayout()
        #self.server_label = QLabel("Server:")
        #self.server_input = QLineEdit()
        #server_layout.addWidget(self.server_label)
        #server_layout.addWidget(self.server_input)
        #left_side_layout.addLayout(server_layout)

        #game_info_layout = QVBoxLayout()
        #game_info_details_layout = QHBoxLayout()
        #self.role_label = QLabel("Role:")
        #self.role_value = QLabel("None")
        #self.cs_label = QLabel("Captain Score:")
        #self.cs_value = QLabel("0")
        #self.gs_label = QLabel("General Score:")
        #self.gs_value = QLabel("0")
        #game_info_details_layout.addWidget(self.role_label)
        #game_info_details_layout.addWidget(self.role_value)
        #game_info_details_layout.addSpacing(20)
        #game_info_details_layout.addWidget(self.cs_label)
        #game_info_details_layout.addWidget(self.cs_value)
        #game_info_details_layout.addSpacing(20)
        #game_info_details_layout.addWidget(self.gs_label)
        #game_info_details_layout.addWidget(self.gs_value)
        #game_info_layout.addLayout(game_info_details_layout)
        #self.game_info_groupbox = QGroupBox("Game Info")
        #self.game_info_groupbox.setLayout(game_info_layout)
        #left_side_layout.addWidget(self.game_info_groupbox)

        #game_board_layout = QVBoxLayout()
        #self.board_grid = QGridLayout()
        #self.board_labels = []

        #for col in range(6):
            #col_label = QLabel(str(col))
            #col_label.setFixedSize(60, 60)
            #col_label.setAlignment(Qt.AlignCenter)
            #col_label.setStyleSheet("font-weight: bold;font-size:24px;")
            #self.board_grid.addWidget(col_label, 0, col + 1)

        #for row in range(6):
            #row_label = QLabel(str(row))
            #row_label.setFixedSize(60, 60)
            #row_label.setAlignment(Qt.AlignCenter)
            #row_label.setStyleSheet("font-weight: bold;font-size: 24px;")
            #self.board_grid.addWidget(row_label, row + 1, 0)

        #for row in range(6):
            #row_labels = []
            #for col in range(6):
                #label = QLabel("")
                #label.setFixedSize(60, 60)
                #label.setStyleSheet("border: 1px solid black; font-size: 24px;")
                #label.setAlignment(Qt.AlignCenter)
                #self.board_grid.addWidget(label, row + 1, col + 1)
                #row_labels.append(label)
            #self.board_labels.append(row_labels)

        #self.board_container = QWidget()
        #self.board_container.setLayout(self.board_grid)
        #self.board_container.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        #game_board_layout.addWidget(self.board_container)
        #self.game_board_groupbox = QGroupBox("Game Board")
        #self.game_board_groupbox.setLayout(game_board_layout)
        #left_side_layout.addWidget(self.game_board_groupbox)

        #self.move_label = QLabel("Move:")
        #self.move_input = QLineEdit()
        #self.move_input.setEnabled(False)
        #self.enter_button = QPushButton("Enter")
        #move_input_layout = QHBoxLayout()
        #move_input_layout.addWidget(self.move_label)
        #move_input_layout.addWidget(self.move_input)
        #move_input_layout.addWidget(self.enter_button)
        #left_side_layout.addLayout(move_input_layout)

        #self.connect_button = QPushButton("Connect")
        #self.chat_button = QPushButton("Chat")
        #connection_button_layout = QHBoxLayout()
        #connection_button_layout.addWidget(self.connect_button)
        #connection_button_layout.addWidget(self.chat_button)
        #right_side_layout.addLayout(connection_button_layout)

        #self.game_status_group = QGroupBox("Game Status")
        #self.game_status_group.setAlignment(Qt.AlignCenter)
        #game_status_layout = QVBoxLayout()
        #self.game_status_label = QLabel("Waiting for connection...")
        #self.game_status_label.setAlignment(Qt.AlignCenter)
        #self.game_status_label.setStyleSheet("font-size: 16px;")
        #game_status_layout.addWidget(self.game_status_label)
        #self.game_status_group.setLayout(game_status_layout)
        #right_side_layout.addWidget(self.game_status_group)

        #self.messages_groupbox = QGroupBox("Messages")
        #self.messages_groupbox_layout = QVBoxLayout()
        #self.message_box = QTextEdit()
        #self.message_box.setReadOnly(True)
        #self.message_box.setMinimumHeight(200)
        #self.messages_groupbox_layout.addWidget(self.message_box)
        #self.messages_groupbox.setLayout(self.messages_groupbox_layout)
        #right_side_layout.addWidget(self.messages_groupbox)

        #self.instructions_button = QPushButton("How To Play")
        #self.exit_button = QPushButton("Exit")
        #button_layout = QHBoxLayout()
        #button_layout.addWidget(self.instructions_button)
        #button_layout.addWidget(self.exit_button)
        #right_side_layout.addLayout(button_layout)

        ## Add layouts to main layout
        #main_layout.addLayout(left_side_layout, 1, 0)
        #main_layout.addLayout(right_side_layout, 1, 1)
        #self.setLayout(main_layout)

        #self.connect_button.clicked.connect(self.connect_button_clicked)
        #self.chat_button.clicked.connect(self.open_chat)
        #self.enter_button.clicked.connect(self.submit_move)
        #self.instructions_button.clicked.connect(self.instructions_button_clicked)
        #self.exit_button.clicked.connect(self.exit_button_clicked)

        ## 🎵 Sound effect for valid move
        #self.valid_move_sound = QMediaPlayer()
        #self.valid_move_sound.setMedia(QMediaContent(QUrl.fromLocalFile("laser-shot-ingame-230500.mp3")))
        #self.valid_move_sound.setVolume(100)

    #def connect_button_clicked(self):
        #server_address = self.server_input.text().strip()
        #if not server_address:
            #self.message_box.append("Please enter a server address.")
            #return

        #self.message_box.append("Getting connection...")
        #self.game_status_label.setText("Getting connection...")
        #QTimer.singleShot(2000, lambda: self.message_box.append("Connecting..."))
        #QTimer.singleShot(2000, lambda: self.game_status_label.setText("Connecting..."))

        #def try_connection():
            #try:
                #self.connect_to_server(server_address)
                #self.message_box.append("Connected to server.")
                #self.game_status_label.setText("Connected")
                #self.recv_thread = ReceiveThread(self.socket)
                #self.recv_thread.message_received.connect(self.handle_message)
                #self.recv_thread.connection_lost.connect(self.on_connection_lost)
                #self.recv_thread.start()
            #except Exception as e:
                #self.message_box.append(f"Connection failed: {e}")
                #self.game_status_label.setText("Connection failed")

        #QTimer.singleShot(3000, try_connection)

    #def on_connection_lost(self):
        #self.message_box.append("⚠️ Connection to server lost.")
        #self.game_status_label.setText("Disconnected")
        #self.move_input.setEnabled(False)

    #def open_chat(self):
        #pass

    #def submit_move(self):
        #move = self.move_input.text().strip()
        #self.send_message(move)
        #self.move_input.setEnabled(False)
        #self.is_my_turn = False

    #def instructions_button_clicked(self):
        #QMessageBox.information(self, "Instructions", "Enter move as 'row,col' (e.g., 2,4).")

    #def exit_button_clicked(self):
        #self.message_box.append("Exit button has been clicked")
        #self.close()

    #def handle_message(self, msg):
        #if msg.startswith("valid move"):
            #info = msg.split(",")
            #move_role = info[1]
            #row = int(info[2])
            #col = int(info[3])
            #new_captain_score = int(info[4])
            #new_general_score = int(info[5])

            ## 🎵 Play sound effect on valid move
            #self.valid_move_sound.play()

            ## Update GUI...
            #mark = move_role.upper() if (new_captain_score > self.captain_score or new_general_score > self.general_score) else move_role.lower()
            #self.board_labels[row][col].setText(mark)
            #color = "red" if move_role == "C" else "blue"
            #self.board_labels[row][col].setStyleSheet(f"font-weight: bold; color: {color}; border-radius:6px; font-size:23px;")
            #self.captain_score = new_captain_score
            #self.general_score = new_general_score
            #self.cs_value.setText(str(self.captain_score))
            #self.gs_value.setText(str(self.general_score))

            #if move_role == self.role:
                #msg = f"Nice shot! You hit a ship at ({row}, {col})!" if mark.isupper() else f"Oops! You missed at ({row}, {col}) nothing but water!!"
            #else:
                #msg = f"Opponent hit a ship at ({row}, {col}) Uh-ohh!" if mark.isupper() else f"Opponent missed at ({row}, {col})."
            #self.message_box.append(msg)

        ## Handle other messages as needed...

#def main():
    #app = QApplication(sys.argv)
    #my_window = User_interface()
    #my_window.show()
    #sys.exit(app.exec_())

#main()